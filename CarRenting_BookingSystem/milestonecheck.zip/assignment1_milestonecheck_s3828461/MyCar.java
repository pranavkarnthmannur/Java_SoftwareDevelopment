package assignment1;

import java.util.*;
import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

// Class MyCar: reads the file and executes the functionalities 
public class MyCar{
	
List<Vehicle_details> vehicleList = new ArrayList<Vehicle_details>();
    
// To read the input file.
    public void ReadRecords(String filename){
        try {
            String line = "";

            BufferedReader br = new BufferedReader(new FileReader(filename)); // to read the file 
                
                while ((line = br.readLine())!= null)
                {
                    String[] cell = line.strip().split(",");
                    Vehicle_details vehicle = new Vehicle_details();
                    vehicle.id = cell[0];
                    vehicle.brand = cell[1];
                    vehicle.model = cell[2];
                    vehicle.type = cell[3];
                    vehicle.year = Integer.parseInt(cell[4]);
                    vehicle.seats = Integer.parseInt(cell[5]);
                    vehicle.colour = cell[6];
                    vehicle.rent = Double.parseDouble(cell[7]);
                    vehicle.insurance = Double.parseDouble(cell[8]);
                    vehicle.fee = Double.parseDouble(cell[9]);
                    vehicle.discount = Double.parseDouble(cell[10]);

                    vehicleList.add(vehicle);

                }         
            } 
        
            catch (IOException e) {
                e.printStackTrace();
            }    
        
    }
    
    // Ask the user for pickup and return date: calculate the total number of days. 
    public long Dates()
    {	
    	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/uuuu");
    	Scanner sc6 = new Scanner(System.in);
    	System.out.println("--------------------------------------------------------------------------------\r\n"
    			+ "> Provide dates\r\n"
    			+ "--------------------------------------------------------------------------------");
    	System.out.print("Please provide pick-up date (dd/mm/yyyy): ");
    	String startdate = sc6.next();
    	System.out.print("Please provide return date (dd/mm/yyyy): ");
    	String returndate = sc6.next();
    	LocalDate date1 = LocalDate.parse(startdate,formatter);
		LocalDate date2 = LocalDate.parse(returndate,formatter);

		long noOfDaysBetween = ChronoUnit.DAYS.between(date1, date2);
		
		return noOfDaysBetween;

    }
    
    // Calculate the total bill and summary of the 
    public void Invoice(Vehicle_details usermodel)
    {
    	System.out.println("Yet to be completed...");
    	System.out.println();
    	System.out.println();
    	System.out.println(usermodel.getId()+" "+usermodel.getBrand() +" "+ usermodel.getModel() + " "+ usermodel.getType() +" with "+usermodel.getSeats()+" seats.");
    	System.exit(0);
    }
    

    
    public void Menu(){
        System.out.println("Welcome to MyCar!");
        System.out.println("--------------------------------------------------------------------------------\r\n"
        		+ "> Select from main menu\r\n"
        		+ "--------------------------------------------------------------------------------\r\n"
        		+ " 1) Search by brand\r\n"
        		+ " 2) Browse by vehicle type\r\n"
        		+ " 3) Filter by number of passengers\r\n"
        		+ " 4) Exit\r\n"
        		+ "");
    }

    // Allow the user to choose the car by brand name 
    public Vehicle_details SearchByBrand(){
    	MyCar obj = new MyCar();
    	Scanner sc = new Scanner(System.in);
    	System.out.print("Please provide a brand: ");
    	String brandname = sc.next();

        List<Vehicle_details> brandsearch = new ArrayList<Vehicle_details>();

     // To print the vehicles brands available as a menu option:
        int i = 0;
        for(Vehicle_details v: vehicleList){
            if(v.brand.equals(brandname)){
            	i= i+1;
                brandsearch.add(v);

                System.out.println(i+") " +v.getId()+" "+v.getBrand() +" "+ v.getModel() + " "+ v.getType() +" with "+v.getSeats()+" seats.");
            }
        }
        
        System.out.println(brandsearch.size()+1+") "+"Go to main menu");
        Scanner sc1 = new Scanner(System.in);

        Vehicle_details usermodel = null;
        boolean menubreak1 = false;
        
        while(menubreak1 == false)
        {
        System.out.println("Choose your model");
        int modeloption = sc1.nextInt();

        if(modeloption>=0 && modeloption<=brandsearch.size())
        {

        	usermodel = brandsearch.get(modeloption-1);
        	menubreak1 = true;
        }

        else if(modeloption==brandsearch.size()+1)
        {
        	menubreak1 = true;
        }
        
        else
        {
        	System.out.println("You have enetered an incorrect value");
        	menubreak1 = false;
        }
        
        } 
        
        return usermodel;
        
    }

 // Allow the user to choose the car by type of vehicle 
    public Vehicle_details vehicleType()
    {	
    	MyCar obj = new MyCar();
    	
    	// To print the type of vehicles available as a menu option:
    	Set<String> settype = new HashSet<String>(); 
    	int j = 1;
    	for(Vehicle_details v: vehicleList){
    	 settype.add(v.type);
    	}
    	for(String type: settype)
    	{
       	 System.out.println(j+") "+type);
       	 j = j+1;
    	}
   	System.out.println(settype.size()+1+") "+"Go to main menu");
   	
   	Scanner sc2 = new Scanner(System.in);
    String usertype = null;
    boolean menubreak2 = false;
    // Converting the set to an array: copies the elements and easy to access at the desried location
    String[] arrsettype = settype.toArray(new String[settype.size()]);
    
    ArrayList<Vehicle_details> modelnametype = new ArrayList<Vehicle_details>();
    Vehicle_details usermodel = null;

    while(menubreak2 == false)
    {
    System.out.println("Choose your model");
    int typeoption = sc2.nextInt();
    if(typeoption>=0 && typeoption<=settype.size())
    {
    	usertype = arrsettype[typeoption-1]; // accessing the element from the array
    	menubreak2 = true;
    	int k = 0;
        for(Vehicle_details v: vehicleList){
            if(v.type.equals(usertype)){
            	k = k+1;
            	modelnametype.add(v);
            	System.out.println(k+") " +v.getId()+" "+v.getBrand() +" "+ v.getModel() + " "+ v.getType() +" with "+v.getSeats()+" seats.");
            	
            }
        }
        System.out.println(settype.size()+") "+"Go to main menu");
        

        boolean menubreak3 = false;
        
        while(menubreak3 == false)
        {
        System.out.println("Choose your model");
        Scanner sc3 = new Scanner(System.in);
        int usermodelnametype = sc3.nextInt();
        
        if(usermodelnametype>=0 && usermodelnametype<=modelnametype.size())
        {
        	usermodel = modelnametype.get(usermodelnametype-1);
        	menubreak3 = true;
        }
        else if(usermodelnametype==modelnametype.size()+1)
        {
        	menubreak3 = true;
        }
        else
        {
        	System.out.println("You have entered an incorrect value");
        	menubreak3 = false;
        }
        } 
    
     
        
    }
    else if(typeoption == arrsettype.length+1)
    {
    	menubreak2 = true;
    }
    else
    {
    	System.out.println("You have entered an incorrect value");
    	menubreak2 = false;
    }
    } 
    
    return usermodel;
    }


 // Allow the user to choose the car by number of seats/ passengers
    public Vehicle_details numberPassenger()
    {
    	MyCar obj = new MyCar();
    	Scanner sc4 = new Scanner(System.in);
    	System.out.print("Please provide the number of passengers ");
    	int passengers = sc4.nextInt();

        List<Vehicle_details> passengersearch = new ArrayList<Vehicle_details>();
     // To print the vehicles available as a menu option, based on the number of seats:
        int i = 0;
        for(Vehicle_details v: vehicleList){

            if(v.seats >= passengers){
            	i= i+1;
                passengersearch.add(v);
                System.out.println(i+") " +v.getId()+" "+v.getBrand() +" "+ v.getModel() + " "+ v.getType() +" with "+v.getSeats()+" seats.");

            }
        }
        
        System.out.println(passengersearch.size()+1+") "+"Go to main menu");
        Scanner sc5 = new Scanner(System.in);
        Vehicle_details usermodel = null;
        boolean menubreak3 = false;
        
        while(menubreak3 == false)
        {
        System.out.println("Choose your model");
        int passengeroption = sc4.nextInt();
        if(passengeroption>=0 && passengeroption<=passengersearch.size())
        {

        	usermodel = passengersearch.get(passengeroption-1);
        	menubreak3 = true;
        }

        else if(passengeroption==passengersearch.size()+1)
        {
        	menubreak3 = true;
        }
        else
        {
        	System.out.println("You have enetered an incorrect value");
        	menubreak3 = false;
        }
        } 
        
        return usermodel;	
    }

    // Main method: Entry point of program 
    public static void main(String args[]){
        MyCar obj = new MyCar();
        obj.ReadRecords("Fleet_test.csv");

        String option = null;

        while(true)
        {
        	obj.Menu();
        	Scanner sc = new Scanner(System.in);
        	System.out.println("Please select: ");
            option = sc.next();
            Vehicle_details usermodel = null;

            switch(option){
                case "1":
                    System.out.println ( "You picked option 1" );
                    usermodel = obj.SearchByBrand();
                    if(usermodel!=null)
                    {
                    obj.Dates();
                    obj.Invoice(usermodel);
                    }
                    break;
                case "2":
                    System.out.println ( "You picked option 2" );
                    usermodel = obj.vehicleType();
                    if(usermodel!=null)
                    {
                    obj.Dates();
                    obj.Invoice(usermodel);
                    }
                    break;
                case "3":
                    System.out.println ( "You picked option 3" );
                    usermodel = obj.numberPassenger();
                    if(usermodel!=null)
                    {
                    obj.Dates();
                    obj.Invoice(usermodel);
                    }
                    break;
                    
                case "4": System.out.println("Thank you");
                System.exit(0);
                break;
                
                default:  System.out.println("Please enter a valid input"); break;
                 
        }
        }
    }

}
