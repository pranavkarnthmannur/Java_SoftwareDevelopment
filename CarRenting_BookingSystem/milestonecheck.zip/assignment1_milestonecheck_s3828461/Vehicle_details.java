package assignment1;

// Class entails all the variables required in the Car Renting Application
public class Vehicle_details {
    String id = "";
    String brand = "";
    String model = "";
    String type = "";
    String colour = "";    
    int seats = 0;
    int year = 0;
	double rent = 0;
	double insurance = 0.0;
	double fee =0;
	double discount = 0;
    
// Getters method for the respective variables 
	public String getId() {
		return id;
	}
	public String getBrand() {
		return brand;
	}
	public String getModel() {
		return model;
	}
	public String getType() {
		return type;
	}
	public String getColour() {
		return colour;
	}
	public int getSeats() {
		return seats;
	}
	public int getYear() {
		return year;
	}
	public double getRent() {
		return rent;
	}
	public double getInsurance() {
		return insurance;
	}
	public double getFee() {
		return fee;
	}
	public double getDiscount() {
		return discount;
	}
	

}
